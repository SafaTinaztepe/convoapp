is a library for composing asynchronous and event-based programs using observable collections and LINQ-style query operators in Python.


